# TARGETED OUTREACH CADENCE: PREETHI BHAT (IBM)
**Recipient:** Preethi Bhat (Talent Acquisition Coordinator)  
**Target Requisition:** Supply Chain & Operations Consultant (BLR-JOB-009)  
**Target ID:** STRK-019  
**Opportunity Score:** 78.0/100 | **Priority:** P0 - High Affinity  

---

### TOUCHPOINT 1: LINKEDIN CONNECTION REQUEST NOTE (< 300 Characters)
```text
Hi Preethi, I saw IBM's opening for Supply Chain & Operations Consultant (BLR-JOB-009) in Bangalore. I have led 300+ operations deployments (AERO India 2025), enforced Tier-1 vendor SLA governance, and finish my BBA (Intl Business) at DSU in 2026. Would love to connect!
```

---

### TOUCHPOINT 2: FORMAL INMAIL / DIRECT EMAIL DISPATCH
```text
Subject: Application: Supply Chain & Operations Consultant (BLR-JOB-009) - Aditya Mehra (BBA DSU '26)

Hi Preethi,

I noticed your active talent leadership at IBM and wanted to reach out regarding the Supply Chain & Operations Consultant requisition (BLR-JOB-009) in Bengaluru.

I graduate with a BBA in International Business from Dayananda Sagar University (DSU) in 2026. My core track centers on high-velocity ground execution and operations governance:

1. Operational Rigor: Lead Coordinator at AERO India 2025 (Yelahanka AFB) and enterprise activations for Puma India & Tata Communications across 300+ on-ground deployments.
2. Cost & Vendor Governance: Standardized Tier-1 supplier rate cards and enforced milestone SLA contracts.
3. Technical & Process Foundations: AI Data Ops at Instawork (99%+ QA precision) and deep grasp of Incoterms 2020 cross-border logistics.

I have attached my tailored resume and would welcome a brief 5-minute screen this week.

Warm regards,
Aditya Mehra
Phone: +91-7003456624 | Email: adityamehra799@gmail.com
Bengaluru, India
```

---

### TOUCHPOINT 3: DAY-4 VALUE-ADD FOLLOW-UP NOTE
```text
Subject: Re: Application: Supply Chain & Operations Consultant (BLR-JOB-009) - Proof of Work

Hi Preethi,

Following up on my note regarding the Supply Chain & Operations Consultant opening. I prepared a brief 1-page operational run-of-show summary demonstrating how I manage vendor SLAs and eliminate dispatch bottlenecks:
- Structured milestone rate cards enforcing zero delivery downtime.
- Zero-downtime protocol tested across 100k+ attendee crowd environments at AERO India.

Looking forward to connecting when your schedule allows.

Best,
Aditya Mehra
```
